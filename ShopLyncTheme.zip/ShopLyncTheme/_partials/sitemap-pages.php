<ul id="sitemap-pages">
<?php
wp_list_pages( array( 
  'exclude' => '',
  'title_li' => '',
  'link_before' => '',
  'link_after' => '',
) );
?>
</ul>